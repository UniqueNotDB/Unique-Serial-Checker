﻿#include <iostream>
#include <chrono>
#include <thread>
#include <windows.h>
#include <fstream>
#include <string>
#include <sstream>
#include <stdio.h>
#include <locale>
#include <codecvt>
#include <filesystem>


bool serialschange = false;

std::string executeCommand(const char* cmd) {
    std::ostringstream stream;
    FILE* pipe = _popen(cmd, "r");
    if (!pipe) return "ERROR";
    char buffer[128];
    while (!feof(pipe)) {
        if (fgets(buffer, 128, pipe) != NULL)
            stream << buffer;
    }
    _pclose(pipe);
    return stream.str();
}

void slowType(const std::string& message, int delay) {
    for (char c : message) {
        std::cout << c << std::flush;
        std::this_thread::sleep_for(std::chrono::milliseconds(delay));
    }
}

std::string readFileToString(const std::wstring& filename) {
    std::wifstream file(filename);
    if (!file.is_open()) {
        std::wcerr << L"Error: Unable to open file " << filename << std::endl;
        return "";
    }

    std::wstring content;
    std::wstring line;
    while (std::getline(file, line)) {
        content += line + L"\n"; // Append newline character after each line
    }

    return std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>>().to_bytes(content);
}

std::wstring getExeDirectory() {
    wchar_t buffer[MAX_PATH];
    GetModuleFileNameW(NULL, buffer, MAX_PATH);
    std::wstring::size_type pos = std::wstring(buffer).find_last_of(L"\\/");
    return std::wstring(buffer).substr(0, pos);
}

bool fileExists(const std::wstring& filename) {
    std::wifstream file(filename);
    return file.good(); // Check if file stream is in a good state (i.e., file exists)
}

void Checkserials() {
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    std::string disk = executeCommand("for /f \"skip=1 tokens=2 delims==\" %i in ('wmic diskdrive get serialnumber /value') do @echo %i");
    std::string bios = executeCommand("for /f \"skip=1 tokens=2 delims==\" %i in ('wmic bios get serialnumber /value') do @echo %i");
    std::string cpu = executeCommand("for /f \"skip=1 tokens=2 delims==\" %i in ('wmic cpu get serialnumber /value') do @echo %i");
    std::string baseboard = executeCommand("for /f \"skip=1 tokens=2 delims==\" %i in ('wmic baseboard get serialnumber /value') do @echo %i");
    std::string systems = executeCommand("for /f \"skip=1 tokens=2 delims==\" %i in ('wmic csproduct get uuid /value') do @echo %i");
    std::string mac = executeCommand("getmac | findstr /v /c:\"Physical Address    Transport Name\" | findstr /v /c:\"=================== ==========================================================\"");
    
    std::string Serials = "Disk:\n"+ disk + "\nBios:\n" + bios + "\nCPU:\n" + cpu + "\nBaseboard:\n" + baseboard + "\nSystem:\n" + systems + "\nMAC:" + mac;
    std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>> converter;
    std::wstring WSerials = converter.from_bytes(Serials);

    std::wstring exeDir = getExeDirectory();
    std::wstring filename = exeDir + L"\\serials.txt";
    if (fileExists(filename)) {
        std::string FileSerials = readFileToString(filename);

        if (FileSerials == Serials) {
            serialschange = false;
        }
        else {
            serialschange = true;
        }
    }
    else {
        serialschange = false;
    }

    system("cls");
    SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | FOREGROUND_INTENSITY);
    const char* logo = R"(
  _    _       _                     _____ _               _             
 | |  | |     (_)                   / ____| |             | |            
 | |  | |_ __  _  __ _ _   _  ___  | |    | |__   ___  ___| | _____ _ __ 
 | |  | | '_ \| |/ _` | | | |/ _ \ | |    | '_ \ / _ \/ __| |/ / _ \ '__|
 | |__| | | | | | (_| | |_| |  __/ | |____| | | |  __/ (__|   <  __/ |   
  \____/|_| |_|_|\__, |\__,_|\___|  \_____|_| |_|\___|\___|_|\_\___|_|   
                    | |                                                  
                    |_|                                                                                                                                                           
                                                 
)";
    std::cout << logo;
    SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
    std::cout << "\033[94m----------------------------------> \033[94m.gg/uniqueproducts \033[94m<----------------------------------\n";
    slowType("\033[92m[!] Disk Drive Serials:\033[0m", 20);
    std::cout << "\n";
    std::cout << disk;
    std::cout << "\n";
    slowType("\033[92m[!] BIOS Serial Number:\n\033[0m", 20);
    std::cout << bios;
    std::cout << "\n";
    slowType("\033[92m[!] CPU Serial Number:\n\033[0m", 20);
    std::cout << cpu;
    std::cout << "\n";
    slowType("\033[92m[!] Baseboard Serial Number:\n\033[0m", 20);
    std::cout << baseboard;
    std::cout << "\n";
    slowType("\033[92m[!] System Serial Number:\n\033[0m", 20);
    std::cout << systems;
    std::cout << "\n";
    slowType("\033[92m[!] Mac Addresses:\033[0m", 20);
    std::cout << mac;
    std::cout << "\n";
    if (serialschange) {
        slowType("\033[92m[+] Some Serials Changed!\n\033[0m", 20);
    }
    else {
        slowType("\033[92m[!] No Serials Changed!\n\033[0m", 20);
    }

    slowType("\033[92m\n[+] Press [F1] to see serials again! Press [F2] to save them to check for changes!", 20);
    while (true)
    {
        if (GetAsyncKeyState(VK_F1) & 0x8000) {
            Checkserials();
        }
        if (GetAsyncKeyState(VK_F2) & 0x8000) {
            std::wstring exeDir = getExeDirectory();
            std::wofstream SerialsFile(exeDir + L"\\serials.txt");
            if (SerialsFile.is_open() && SerialsFile.good()) {
                SerialsFile << WSerials;
                SerialsFile.close();
                std::wcout << L"\n[+] Made Serials File! (serials.txt) Refreshing in 5 seconds...\n" << std::endl;
                Sleep(5000);
                Checkserials();
                break;
            }
            else {
                std::wcerr << L"Error: Unable to create or open the file!\n";
            }
        }
        Sleep(100);
    }
}

int main()
{
    Checkserials();
    return 0;
}
